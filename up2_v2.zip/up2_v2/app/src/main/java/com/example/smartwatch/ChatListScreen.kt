package com.example.smartwatch

import android.app.Activity
import android.os.Bundle
import com.example.smartwatch.databinding.ActivityChatListScreenBinding

class ChatListScreen : Activity() {

    private lateinit var binding: ActivityChatListScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityChatListScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }
}