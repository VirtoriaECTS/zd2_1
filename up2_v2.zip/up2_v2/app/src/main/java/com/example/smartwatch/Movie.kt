package com.example.smartwatch

data class Movie(
    val Title: String,
    val Poster: String
)
