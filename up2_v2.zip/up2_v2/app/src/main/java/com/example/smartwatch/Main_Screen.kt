package com.example.smartwatch

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import com.example.smartwatch.databinding.ActivityMainScreen2Binding

class Main_Screen : Activity() {

    private lateinit var binding: ActivityMainScreen2Binding

    private lateinit var speak:ImageButton
    private lateinit var speak2:ImageButton
    private lateinit var loveButton:ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainScreen2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        speak=findViewById(R.id.discussionsImageView)
        speak2=findViewById(R.id.setsImageView)
        loveButton=findViewById(R.id.favouritesImageView)

        speak.setOnClickListener{
            val intent=Intent(this,ChatListScreen::class.java)
            startActivity(intent)
        }
        speak2.setOnClickListener {
            val intent=Intent(this, ChatListScreen::class.java)
            startActivity(intent)
        }
        loveButton.setOnClickListener {
            val intent=Intent(this, MoviesScreen::class.java)
            startActivity(intent)
        }
    }
}