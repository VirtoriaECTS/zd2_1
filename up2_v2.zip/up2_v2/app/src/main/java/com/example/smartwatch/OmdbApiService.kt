package com.example.smartwatch

import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.Call


interface OmdbApiService {

    @GET("/")
    fun getMovieDetails(
        @Query("apikey") apiKey: String,
        @Query("t") title: String,
        @Query("plot") plot: String = "full"
    ): Call<Movie>
}